//
//  CustomRecipeComposeViewController.h
//  Recipe Directory
//
//  Created by Aditya Anil Gidh on 12/9/14.
//  Copyright (c) 2014 neu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomRecipeComposeViewController : UIViewController{
    NSMutableArray *recipesArray;
    NSManagedObjectContext *managedObjectContext;
}


@property (nonatomic, retain) NSMutableArray *recipesArray;
@property (nonatomic, retain) NSManagedObjectContext *managedObjectContext;

@end
