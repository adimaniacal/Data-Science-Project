//
//  ResultsViewController.h
//  Recipe Directory
//
//  Created by Aditya Anil Gidh on 12/9/14.
//  Copyright (c) 2014 neu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ResultsViewController : UITableViewController

-(void)setSearchParametersAndFetchRecipes:(NSString *)keyword withIngredients:(NSString *)ingredients;

@property (nonatomic, retain) NSManagedObjectContext *managedObjectContext;
@property (nonatomic, retain) NSMutableArray *favoritesArray;

@end
