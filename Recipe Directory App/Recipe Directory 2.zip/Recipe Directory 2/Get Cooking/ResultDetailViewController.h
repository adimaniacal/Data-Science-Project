//
//  ResultDetailViewController.h
//  Recipe Directory
//
//  Created by Aditya Anil Gidh on 12/9/14.
//  Copyright (c) 2014 neu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ResultDetailViewController : UIViewController

-(void)setUrl:(NSString *)u andIngredients:(NSString *)i;

@end
