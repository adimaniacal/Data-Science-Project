//
//  Favorite.m
//  Recipe Directory
//
//  Created by Aditya Anil Gidh on 12/9/14.
//  Copyright (c) 2014 neu. All rights reserved.
//

#import "Favorite.h"


@implementation Favorite

@dynamic title;
@dynamic html;
@dynamic ingredients;

- (NSString *)typeOfRecipe{
    return @"Favorite";
}


@end
