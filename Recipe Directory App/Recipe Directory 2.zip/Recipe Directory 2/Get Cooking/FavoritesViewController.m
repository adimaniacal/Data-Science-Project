//
//  FavoriteViewController.m
//  Recipe Directory
//
//  Created by Aditya Anil Gidh on 12/9/14.
//  Copyright (c) 2014 neu. All rights reserved.
//

#import "FavoritesViewController.h"
#import "FavoriteDetailViewController.h"
#import "CustomRecipeDetailViewController.h"
#import "AppDelegate.h"
#import "Favorite.h"
#import "PersonalRecipe.h"

@interface FavoritesViewController ()

@property (strong, nonatomic) IBOutlet UINavigationBar *navBar;
@property (strong, nonatomic) NSString *selectedHtml;
@property (strong, nonatomic) NSString *selectedIngredients;
@property (strong, nonatomic) NSString *selectedInstructions;
@property (strong, nonatomic) NSString *selectedTitle;

@end

@implementation FavoritesViewController

@synthesize favoritesArray;
@synthesize managedObjectContext;
@synthesize navBar;
@synthesize selectedHtml;
@synthesize selectedIngredients;
@synthesize selectedInstructions;
@synthesize selectedTitle;

- (IBAction)addPressed:(UIBarButtonItem *)sender {
    [self performSegueWithIdentifier:@"ShowRecipeComposeView" sender:self];
}

- (IBAction)xPressed:(UIBarButtonItem *)sender {
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)getRecipes{
    //Get the Managed Object Context
    AppDelegate *d = [UIApplication sharedApplication].delegate;
    self.managedObjectContext = d.getContext;
    NSManagedObjectContext *context = [self managedObjectContext];
    if (!context) {
       
        UIAlertView *v = [[UIAlertView alloc] initWithTitle:@"Error!" message:@"Failed to load managed object context." delegate:self cancelButtonTitle:@"Oh!" otherButtonTitles:nil];
        [v show];
    }
    
    
    NSFetchRequest *request = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"Favorite" inManagedObjectContext:managedObjectContext];
    [request setEntity:entity];
    
    
    NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc] initWithKey:@"title" ascending:YES];
    NSArray *sortDescriptors = [[NSArray alloc] initWithObjects:sortDescriptor, nil];
    [request setSortDescriptors:sortDescriptors];
    
    NSError *error = nil;
    
   
    NSFetchRequest *otherRequest = [[NSFetchRequest alloc] init];
    NSEntityDescription *personalRecipe = [NSEntityDescription entityForName:@"PersonalRecipe" inManagedObjectContext:managedObjectContext];
    
    [otherRequest setEntity:personalRecipe];
    [otherRequest setSortDescriptors:sortDescriptors];
    
    
    NSMutableArray *mutableFetchResults = [[managedObjectContext executeFetchRequest:request error:&error] mutableCopy];
    if (mutableFetchResults == nil) {
        // Handle the error.
        UIAlertView *v = [[UIAlertView alloc] initWithTitle:@"Save Error!" message:@"Could not fetch the HTML recipes!" delegate:self cancelButtonTitle:@"Oh!" otherButtonTitles:nil];
        [v show];
    }
    
    NSMutableArray *personalRecipeFetchResults = [[managedObjectContext executeFetchRequest:otherRequest error:&error] mutableCopy];
    if (personalRecipeFetchResults == nil) {
        // Handle the error.
        UIAlertView *v = [[UIAlertView alloc] initWithTitle:@"Save Error!" message:@"Could not fetch your Personal recipes!" delegate:self cancelButtonTitle:@"Oh!" otherButtonTitles:nil];
        [v show];
    }
    
    NSMutableArray *allResults = [[NSMutableArray alloc] init];
    [allResults addObjectsFromArray:mutableFetchResults];
    [allResults addObjectsFromArray:personalRecipeFetchResults];
    
    
    [self setFavoritesArray:allResults];
    
    [favoritesArray sortUsingDescriptors:sortDescriptors];
}

- (void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [self getRecipes];
    [self.tableView reloadData];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self getRecipes];
    
    [self.navBar setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:[UIColor whiteColor], UITextAttributeTextColor, [UIFont fontWithName:@"Times New Roman Text" size:21.0], UITextAttributeFont, nil]];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{

   
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{

   
    return [favoritesArray count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier forIndexPath:indexPath];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier];
    }
    
    // Configure the cell...
    Favorite *favorite = (Favorite *)[favoritesArray objectAtIndex:indexPath.row];
    
    cell.textLabel.text = [favorite title];
    cell.detailTextLabel.text = [favorite ingredients];

    return cell;
}

- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath{
    
    cell.backgroundColor = [UIColor colorWithWhite:1.0 alpha:0.9];
    cell.textLabel.backgroundColor = [UIColor colorWithWhite:1.0 alpha:0.9];
    cell.detailTextLabel.backgroundColor = [UIColor colorWithWhite:1.0 alpha:0.9];
}

- (NSString *)tableView:(UITableView *)tableView titleForDeleteConfirmationButtonForRowAtIndexPath:(NSIndexPath *)indexPath{
    return @"Delete";
}

// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        
        NSManagedObject *favoriteToDelete = [favoritesArray objectAtIndex:indexPath.row];
        [managedObjectContext deleteObject:favoriteToDelete];
        
     
        [favoritesArray removeObjectAtIndex:indexPath.row];
        [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:YES];
        
        
        NSError *error;
        if (![managedObjectContext save:&error]) {
            // Handle the error.
            UIAlertView *v = [[UIAlertView alloc] initWithTitle:@"Save Error!" message:@"Could not save your recipes!" delegate:self cancelButtonTitle:@"Oh wait!" otherButtonTitles:nil];
            [v show];
        }
    }  
}

#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    if ([[[favoritesArray objectAtIndex:indexPath.row] typeOfRecipe] isEqualToString:@"Favorite"]) {
        
        selectedHtml = [[favoritesArray objectAtIndex:indexPath.row] html];
        selectedIngredients = [[favoritesArray objectAtIndex:indexPath.row] ingredients];

        [self performSegueWithIdentifier:@"ShowFavoriteDetailView" sender:self];

    }
    else if([[[favoritesArray objectAtIndex:indexPath.row] typeOfRecipe] isEqualToString:@"PersonalRecipe"]){
        
        selectedInstructions = [[favoritesArray objectAtIndex:indexPath.row] instructions];

        selectedIngredients = [[favoritesArray objectAtIndex:indexPath.row] ingredients];

        selectedTitle = [[favoritesArray objectAtIndex:indexPath.row] title];

        
        [self performSegueWithIdentifier:@"ShowPersonalRecipeDetailView" sender:self];

    }

}

-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    if ([[segue identifier] isEqualToString:@"ShowFavoriteDetailView"]) {
        
        FavoriteDetailViewController *target = [segue destinationViewController];
        [target setUrl:selectedHtml andIngredients:selectedIngredients];
    }
    if([[segue identifier] isEqualToString:@"ShowPersonalRecipeDetailView"]){
        
        CustomRecipeDetailViewController *otherTarget = [segue destinationViewController];
        [otherTarget setRecipeTitle:selectedTitle withIngredients:selectedIngredients withInstructions:selectedInstructions];
    }
}

@end
