//
//  CustomRecipeComposeViewController.m
//  Recipe Directory
//
//  Created by Aditya Anil Gidh on 12/9/14.
//  Copyright (c) 2014 neu. All rights reserved.
//

#import "CustomRecipeComposeViewController.h"
#import "AppDelegate.h"
#import "PersonalRecipe.h"

@interface CustomRecipeComposeViewController () <UIAlertViewDelegate, UITextFieldDelegate, UITextViewDelegate>

@property (strong, nonatomic) IBOutlet UITextField *titleField;

@property (strong, nonatomic) IBOutlet UITextField *ingredientField;

@property (strong, nonatomic) IBOutlet UITextView *recipeTextView;

@property (strong, nonatomic) IBOutlet UIScrollView *scrollView;

@property (strong, nonatomic) IBOutlet UINavigationBar *navBar;

@end

@implementation CustomRecipeComposeViewController

@synthesize titleField;
@synthesize ingredientField;
@synthesize recipeTextView;
@synthesize scrollView;
@synthesize navBar;
@synthesize recipesArray;
@synthesize managedObjectContext;


- (IBAction)savePressed:(UIBarButtonItem *)sender {
    
    PersonalRecipe *recipe = (PersonalRecipe *)[NSEntityDescription insertNewObjectForEntityForName:@"PersonalRecipe" inManagedObjectContext:managedObjectContext];
    
    [recipe setTitle:[titleField text]];
    [recipe setIngredients:[ingredientField text]];
    [recipe setInstructions:[recipeTextView text]];
    
    NSError *error = nil;
    if (![managedObjectContext save:&error]) {
        
        UIAlertView *v = [[UIAlertView alloc] initWithTitle:@"Error while saving!" message:@"Could not save your new recipe!" delegate:self cancelButtonTitle:@"Cancel?!" otherButtonTitles:nil];
        [v show];
    }

    UIAlertView *b = [[UIAlertView alloc] initWithTitle:@"Very good!" message:@"You managed to save your recipe successfully!" delegate:self cancelButtonTitle:@"Close?" otherButtonTitles:nil];
    [b show];

}


- (IBAction)xPressed:(UIBarButtonItem *)sender {
    
    UIAlertView *a = [[UIAlertView alloc] initWithTitle:@"Look!" message:@"Cancel without saving?" delegate:self cancelButtonTitle:@"YES!" otherButtonTitles:@"NO!",nil];
    [a show];
}

- (IBAction)scrollViewTapped:(UITapGestureRecognizer *)sender {
    [ingredientField resignFirstResponder];
    [recipeTextView resignFirstResponder];
    [titleField resignFirstResponder];
    [self setEditing:NO];
}


- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if (buttonIndex == [alertView firstOtherButtonIndex]) {
        
    }
    else{
        [self dismissViewControllerAnimated:YES completion:nil];
    }
}

- (void)textViewDidBeginEditing:(UITextView *)textView{
    [recipeTextView setText:@""];
}



- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
       
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    
    AppDelegate *d = [UIApplication sharedApplication].delegate;
    self.managedObjectContext = d.getContext;
    NSManagedObjectContext *context = [self managedObjectContext];
    if (!context) {
        //handle the error
        UIAlertView *v = [[UIAlertView alloc] initWithTitle:@"Save Error!" message:@"Could not find managed object context!" delegate:self cancelButtonTitle:@"Cancel?" otherButtonTitles:nil];
        [v show];
    }
    
    
    NSFetchRequest *request = [[NSFetchRequest alloc] init];
    NSEntityDescription *entity = [NSEntityDescription entityForName:@"PersonalRecipe" inManagedObjectContext:managedObjectContext];
    [request setEntity:entity];
    
   
    NSSortDescriptor *sortDescriptor = [[NSSortDescriptor alloc] initWithKey:@"title" ascending:YES];
    NSArray *sortDescriptors = [[NSArray alloc] initWithObjects:sortDescriptor, nil];
    [request setSortDescriptors:sortDescriptors];
    
    NSError *error = nil;
    NSMutableArray *mutableFetchResults = [[managedObjectContext executeFetchRequest:request error:&error] mutableCopy];
    if (mutableFetchResults == nil) {
        
        UIAlertView *v = [[UIAlertView alloc] initWithTitle:@"Save Error!" message:@"Could not fetch your recipes!" delegate:self cancelButtonTitle:@"Oh wait!" otherButtonTitles:nil];
        [v show];
    }
    
    [self setRecipesArray:mutableFetchResults];
    
    
	
    [self registerForKeyboardNotifications];
    [titleField setDelegate:self];
    [ingredientField setDelegate:self];
    [recipeTextView setDelegate:self];
    [self.navBar setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:[UIColor whiteColor], UITextAttributeTextColor, [UIFont fontWithName:@"Hoefler Text" size:21.0], UITextAttributeFont, nil]];

}


- (void)registerForKeyboardNotifications
{
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWasShown:)
                                                 name:UIKeyboardDidShowNotification object:nil];
    
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWillBeHidden:)
                                                 name:UIKeyboardWillHideNotification object:nil];
    
}


- (void)keyboardWasShown:(NSNotification*)aNotification
{

    NSDictionary* info = [aNotification userInfo];
    CGSize kbSize = [[info objectForKey:UIKeyboardFrameBeginUserInfoKey] CGRectValue].size;
    
    UIEdgeInsets contentInsets = UIEdgeInsetsMake(0.0, 0.0, kbSize.height, 0.0);
    scrollView.contentInset = contentInsets;
    scrollView.scrollIndicatorInsets = contentInsets;
    
    
    CGRect aRect = self.view.frame;
    aRect.size.height -= kbSize.height;
    if (!CGRectContainsPoint(aRect, ingredientField.frame.origin)) {
        CGPoint scrollPoint = CGPointMake(0.0, ingredientField.frame.origin.y-kbSize.height);
        [scrollView setContentOffset:scrollPoint animated:YES];
    }
    if (!CGRectContainsPoint(aRect, titleField.frame.origin)) {
        CGPoint scrollPoint = CGPointMake(0.0, titleField.frame.origin.y-kbSize.height);
        [scrollView setContentOffset:scrollPoint animated:YES];
    }
    if (!CGRectContainsPoint(aRect, recipeTextView.frame.origin)) {
        CGPoint scrollPoint = CGPointMake(0.0, recipeTextView.frame.origin.y-kbSize.height);
        [scrollView setContentOffset:scrollPoint animated:YES];
    }
}

- (void)keyboardWillBeHidden:(NSNotification*)aNotification
{
    UIEdgeInsets contentInsets = UIEdgeInsetsZero;
    scrollView.contentInset = contentInsets;
    scrollView.scrollIndicatorInsets = contentInsets;
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];

}

@end
