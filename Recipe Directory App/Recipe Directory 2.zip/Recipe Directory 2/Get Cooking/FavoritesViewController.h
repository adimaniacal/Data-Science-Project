//
//  FavoriteViewController.h
//  Recipe Directory
//
//  Created by Aditya Anil Gidh on 12/9/14.
//  Copyright (c) 2014ß neu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FavoritesViewController : UITableViewController{
    NSMutableArray *favoritesArray;
    NSManagedObjectContext *managedObjectContext;
}


@property (nonatomic, retain) NSMutableArray *favoritesArray;
@property (nonatomic, retain) NSManagedObjectContext *managedObjectContext;

@end
