//
//  CustomRecipeDetailViewController.m
//  Recipe Directory
//
//  Created by Aditya Anil Gidh on 12/9/14.
//  Copyright (c) 2014 neu. All rights reserved.
//

#import "CustomRecipeDetailViewController.h"

@interface CustomRecipeDetailViewController () <UITableViewDataSource, UITableViewDelegate>


@property (strong, nonatomic) IBOutlet UITableView *table;

@property (strong, nonatomic) IBOutlet UINavigationBar *navigationBar;
@property (strong, nonatomic) IBOutlet UILabel *title;
@property (strong, nonatomic) IBOutlet UITextView *ingredientsView;
@property (strong, nonatomic) IBOutlet UITextView *instructionsView;
@property (strong, nonatomic) IBOutlet UIScrollView *scrollView;
@property (strong, nonatomic) NSMutableArray *ingredientsList;

@property (strong, nonatomic) NSString *a;
@property (strong, nonatomic) NSString *b;
@property (strong, nonatomic) NSString *c;

@end

@implementation CustomRecipeDetailViewController

@synthesize navigationBar;
@synthesize title;
@synthesize ingredientsView;
@synthesize instructionsView;
@synthesize scrollView;
@synthesize table;

@synthesize ingredientsList;

@synthesize a;
@synthesize b;
@synthesize c;

- (void)setRecipeTitle:(NSString *)t withIngredients:(NSString *)i withInstructions:(NSString *)n{
    a = t;
    b = i;
    c = n;
    [self setIngredientsList:[[i componentsSeparatedByString:@", "] copy]];
}

- (IBAction)xPressed:(UIBarButtonItem *)sender {
    [self dismissViewControllerAnimated:YES completion:nil];
}



- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];

}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self.table setDelegate:self];
    [self.table setDataSource:self];
    [self.table setAllowsMultipleSelection:YES];

    [self.navigationBar topItem].title = a;
    [self.navigationBar setTitleTextAttributes:[NSDictionary dictionaryWithObjectsAndKeys:[UIColor whiteColor], UITextAttributeTextColor, [UIFont fontWithName:@"Times New Roman Text" size:21.0], UITextAttributeFont, nil]];

    [ingredientsView setText:b];
    [instructionsView setText:c];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [ingredientsList count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier forIndexPath:indexPath];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    
    cell.textLabel.text = [ingredientsList objectAtIndex:indexPath.row];
    return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if ([[tableView cellForRowAtIndexPath:indexPath] alpha] == 1.0) {
        [UIView beginAnimations:nil context:NULL];
        [UIView setAnimationDuration:1.0];
        [[tableView cellForRowAtIndexPath:indexPath] setAlpha:0.4];
        [UIView commitAnimations];
    }
    else if([[tableView cellForRowAtIndexPath:indexPath] alpha] == 0.4){
        [UIView beginAnimations:nil context:NULL];
        [UIView setAnimationDuration:1.0];
        [[tableView cellForRowAtIndexPath:indexPath] setAlpha:1.0];
        [UIView commitAnimations];
    }
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath{
    return NO;
}

/*
- (UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath{

}


- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath{
    if(editingStyle == UITableViewCellEditingStyleDelete){
        
//        [ingredientsList removeObjectAtIndex:indexPath.row];
//        [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:YES];
    }
}
*/

- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath{
    cell.backgroundView.backgroundColor = [UIColor clearColor];
    cell.backgroundColor = [UIColor clearColor];


    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
   
}





@end
