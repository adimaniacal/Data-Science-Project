//
//  Favorite.h
//  Recipe Directory
//
//  Created by Aditya Anil Gidh on 12/9/14.
//  Copyright (c) 2014 neu. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>


@interface Favorite : NSManagedObject

@property (nonatomic, retain) NSString * title;
@property (nonatomic, retain) NSString * html;
@property (nonatomic, retain) NSString * ingredients;

- (NSString *)typeOfRecipe;

@end
