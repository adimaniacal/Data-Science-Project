//
//  PersonalRecipe.m
//  Recipe Directory
//
//  Created by Aditya Anil Gidh on 12/9/14.
//  Copyright (c) 2014 neu. All rights reserved.
//

#import "PersonalRecipe.h"


@implementation PersonalRecipe

@dynamic title;
@dynamic ingredients;
@dynamic instructions;

- (NSString *)typeOfRecipe{
    return @"PersonalRecipe";
}

@end
